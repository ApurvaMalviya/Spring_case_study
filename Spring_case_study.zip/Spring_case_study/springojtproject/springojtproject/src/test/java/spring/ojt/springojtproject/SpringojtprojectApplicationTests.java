package spring.ojt.springojtproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringojtprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
